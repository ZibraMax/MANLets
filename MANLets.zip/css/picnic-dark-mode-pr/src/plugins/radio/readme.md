## Radio button

A simple way of using radiobuttons

```html
<label>
  <input type='radio' name="radiodemo">
  <span class="checkable">Select me</span>
</label><br><br>

<input id="radiodemo" checked type='radio' name="radiodemo">
<label for="radiodemo" class="checkable">Or me</label>
```
