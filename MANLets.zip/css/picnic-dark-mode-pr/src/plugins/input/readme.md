## Input

Simple (or not) text form elements:

```html
<fieldset class="flex two">
  <label><input type="email" placeholder="Email"></label>
  <label><input type="password" placeholder="Password"></label>
</fieldset>
<textarea placeholder="Textarea"></textarea>
```

<style>
input.demo {
  margin-bottom: .3em;
}
</style>
