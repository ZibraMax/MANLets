## Select

```html
<select>
  <option>Select an option</option>
  <option>Good option</option>
  <option>Nice option</option>
  <option>Cheap option</option>
</select>
```